library(testthat)
library(CoGAPS)

test_check("CoGAPS")
