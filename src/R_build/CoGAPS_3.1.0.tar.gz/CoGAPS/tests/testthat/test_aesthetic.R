#context("lints")

#test_that("Package Style", {
#    skip("Don't lint for now")
#    lintr::expect_lint_free()
#})
